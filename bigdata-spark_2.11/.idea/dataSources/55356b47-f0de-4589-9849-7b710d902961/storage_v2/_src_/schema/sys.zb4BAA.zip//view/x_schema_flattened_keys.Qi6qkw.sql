create definer = `mysql.sys`@localhost view x$schema_flattened_keys as
select `STATISTICS`.`TABLE_SCHEMA`                                                                     AS `TABLE_SCHEMA`,
       `STATISTICS`.`TABLE_NAME`                                                                       AS `TABLE_NAME`,
       `STATISTICS`.`INDEX_NAME`                                                                       AS `INDEX_NAME`,
       max(`STATISTICS`.`NON_UNIQUE`)                                                                  AS `non_unique`,
       max(if((`STATISTICS`.`SUB_PART` is null), 0, 1))                                                AS `subpart_exists`,
       group_concat(`STATISTICS`.`COLUMN_NAME` order by `STATISTICS`.`SEQ_IN_INDEX` ASC separator
                    ',')                                                                               AS `index_columns`
from `information_schema`.`STATISTICS`
where ((`STATISTICS`.`INDEX_TYPE` = 'BTREE') and
       (`STATISTICS`.`TABLE_SCHEMA` not in ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
group by `STATISTICS`.`TABLE_SCHEMA`, `STATISTICS`.`TABLE_NAME`, `STATISTICS`.`INDEX_NAME`;

